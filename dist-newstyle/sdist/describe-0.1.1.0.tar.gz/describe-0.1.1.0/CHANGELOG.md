# Revision history for describe

## 0.1.1.0 -- 2019-09-05

* Added Monad instance for Descriptor

## 0.1.0.0 -- 2019-06-03

* Initial release.
